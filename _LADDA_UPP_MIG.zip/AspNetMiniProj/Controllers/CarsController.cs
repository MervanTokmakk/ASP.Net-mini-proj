﻿using Microsoft.AspNetCore.Mvc;
using AspNetMiniProj.Models;
using AspNetMiniProj.Views.Cars;

namespace AspNetMiniProj.Controllers
{
	public class CarsController : Controller
	{
		DataService dataService;

		public CarsController(DataService dataService)
		{
            this.dataService = dataService;
        }

		[HttpGet("/")]
		public IActionResult Index()
		{
			var cars = dataService.GetAllCars();
			return View(cars);
		}

		[HttpGet("/detail/{Id}")]
		public IActionResult Detail(int id)
		{
			var car = dataService.GetCarById(id);
			var model = new DetailVM
			{
				Brand = car.Brand,
				Model = car.Model,
				Price = car.Price,
				ChassiNumber = car.ChassiNumber
            };
			return View(model);
		}

		[HttpPost("create")]
		public IActionResult Create(CreateVM createVM)
		{
			dataService.AddCar(createVM);
			return RedirectToAction(nameof(Index));

		}

		[HttpGet("create")]
		public IActionResult Create()
		{
			return View();
		}


	}
}
