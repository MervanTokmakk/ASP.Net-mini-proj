﻿using System.ComponentModel.DataAnnotations;

namespace AspNetMiniProj.Models
{
	public class Car
	{
		//[Required(ErrorMessage = "Please enter the price of the car in SEK")]
		public int Price { get; set; }

        //[Range(4, 4, ErrorMessage = "Wrong answer")]
        public int ChassiNumber { get; set; }

		//[Required(ErrorMessage = "Please enter a brand")]
		public string Brand { get; set; }

		//[Required(ErrorMessage = "Please enter a car model")]
		public string Model { get; set; }
	}
}
