﻿using AspNetMiniProj.Views.Cars;

namespace AspNetMiniProj.Models
{

	public class DataService
	{
		List<Car> cars = new List<Car>
		{
			new Car { Brand = "Audi", Model = "A1", Price = 20000, ChassiNumber = 34529104 },
			new Car { Brand = "BMW", Model = "X5", Price = 15000, ChassiNumber = 15096317 },
			new Car { Brand = "Ford", Model = "Mustang", Price = 30000, ChassiNumber = 16459305 },
		};
		public void AddCar(CreateVM createVM)
		{
			cars.Add(new Car { 
			Brand = createVM.Brand,
			Model = createVM.Model,
			Price = createVM.Price,
			ChassiNumber = createVM.ChassiNumber
			});
		}

		public IndexVM[] GetAllCars()
		{
			return cars
				.Select(c => new IndexVM 
				{ 
					Brand = c.Brand,
                    ChassiNumber = c.ChassiNumber
                })
				.ToArray();
		}

		public DetailVM GetCarById(int id)
		{
			return cars
                .Where(c => c.ChassiNumber == id)
                .Select(c => new DetailVM
				{
					Brand = c.Brand,
					Model = c.Model,
					Price = c.Price,
					ChassiNumber = c.ChassiNumber
                })
                .SingleOrDefault();
		}
	}
}
