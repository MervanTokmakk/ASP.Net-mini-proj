using AspNetMiniProj.Models;

namespace AspNetMiniProj
{
    public class Program
    {
        public static void Main(string[] args)
        {
			var builder = WebApplication.CreateBuilder(args);
			builder.Services.AddControllersWithViews();
			builder.Services.AddSingleton<DataService>();

			var app = builder.Build();
			app.UseRouting();
			app.UseEndpoints(endpoints => endpoints.MapControllers());
			app.UseStaticFiles();
			app.Run();
		}
    }
}