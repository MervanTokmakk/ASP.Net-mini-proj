﻿using System.ComponentModel.DataAnnotations;

namespace AspNetMiniProj.Views.Cars
{
    public class CreateVM
    {
        [Required(ErrorMessage = "Please enter the price of the car in SEK")]
        public int Price { get; set; }

        //[StringLength(8, MinimumLength = 8, ErrorMessage = "Must be 8 numbers")]
        //[Range(7, 9, ErrorMessage = "Must be 8 numbers")]
        public int ChassiNumber { get; set; }

        [Required(ErrorMessage = "Please enter a brand")]
        public string Brand { get; set; }

        [Required(ErrorMessage = "Please enter a car model")]
        public string Model { get; set; }

    }
}
