﻿using System.ComponentModel.DataAnnotations;

namespace AspNetMiniProj.Views.Cars
{
    public class DetailVM
    {
        public int Price { get; set; }

        public int ChassiNumber { get; set; }

        public string Brand { get; set; }

        public string Model { get; set; }
    }
}
