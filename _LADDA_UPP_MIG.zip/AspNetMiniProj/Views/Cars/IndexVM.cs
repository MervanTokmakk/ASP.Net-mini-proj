﻿namespace AspNetMiniProj.Views.Cars
{
    public class IndexVM
    {
        public string Brand { get; set; }
        public int ChassiNumber { get; set; }

    }
}
